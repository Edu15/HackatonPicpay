import jinja2
import requests
from flask import Flask, jsonify
import schedule
import time
import threading
 
app = Flask(__name__)
def enviar_email(num):
    import win32com.client as win32
 
    #Interpretação com o outlook
    outlook = win32.Dispatch('outlook.application')
       
    #cria um e-mail
    email= outlook.CreateItem(0)
    #configurando do e-mail a ser enviado
    email.To = 'inaldofreitasjr@gmail.com' #destino
    email.Subject= 'Erro no aws' #assunto
    email.HTMLBody= f'''
    <p><style="background-color: red;">ERRO aws {num}</p>
    ''' #corpo
    email.Send()
    print('Enviado')
 
def buscar_status(regiao, servico):
    mensagem_status = ""
    try:
        url_completa = f"https://status.aws.amazon.com/rss/{servico}-{regiao}.rss"
        resposta = requests.get(url_completa) # realiza a requisição
        status = resposta.status_code
        if status == 200:
            mensagem_status = "OK"
        else:
            enviar_email()
 
    except Exception as e:
        enviar_email(500)
 
    return {
        "Endereço do site": f"\033[94m{url_completa}\033[0m",
        "Região": f"\033[95m{regiao}\033[0m",
        "Serviço": f"\033[96m{servico}\033[0m",
        "Status": f"\033[1m{status}\033[0m",
        "Mensagem de Status": mensagem_status
    }
 
def buscar_status_para_todos_servicos(regiao):
    # lista que contém todos os services da aws em sp e virginia
    servicos = [ "apigateway", "appflow", "appstream2", "athena", "braket",
    "cloudwatchsynthetics",
    "cognito",
    "datazone",
    "detective",
    "dynamodb",
    "elasticfilesystem",
    "elasticache",
    "emrserverless",
    "freertos",
    "fsx",
    "gamelift",
    "glacier",
    "guardduty",
    "inspector",
    "kinesisanalytics",
    "macie",
    "mq",
    "polly",
    "redshift",
    "route53privatedns",
    "route53resolver",
    "sagemaker",
    "securitylake",
    "simpledb",
    "sumerian",
    "transcribe",
    "workspaces",
    "autoscaling",
    "amplifyadmin",
    "amplify",
    "appmesh",
    "appconfig",
    "appsync",
    "backup",
    "batch"]
 
    dados_regiao = {}
    for servico in servicos:
        dados_regiao[servico] = buscar_status(regiao, servico)
 
    return dados_regiao
 
def buscar_todos_os_status():
    regioes = ["us-east-1", "sa-east-1"]
 
    dados_status = {}
    for regiao in regioes:
        dados_status[regiao] = buscar_status_para_todos_servicos(regiao)
 
    return dados_status
 
@app.route('/monitor/<regiao>/<servico>')
def monitorar_website(regiao, servico):
    return jsonify(buscar_status(regiao, servico))
 
@app.route('aws/status', methods=['GET'])
def obter_status():
    return jsonify(buscar_todos_os_status())
 
def verificar_status_aws():
    print("Buscando status...")
    dados_status = buscar_todos_os_status()
    for regiao, dados_regiao in dados_status.items():
        for servico, dados in dados_regiao.items():
            for chave, valor in dados.items():
                print(f"{chave}: {valor}")
            print("\n")
 
 
def verificar_status_em_threaded():
    try:
        thread = threading.Thread(target=verificar_status_aws)
        thread.start()
        thread.join()  # Aguarda até que a thread seja concluída
    except Exception as e:
 
        enviar_email(404)
 
schedule.every(1).minutes.do(verificar_status_em_threaded)
 
if __name__ == "__main__":
    try:
        while True:
            schedule.run_pending()
            time.sleep(1)
    except KeyboardInterrupt:
        print("Encerrando o programa...")