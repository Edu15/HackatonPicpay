#Pega as informações da API
import requests
import schedule
import time

normal_performace = 0
no_normal_performace = 0

def performaceOracleCloudSaoPaulo():
    global normal_performace 
    global no_normal_performace

    url = 'https://ocistatus.oraclecloud.com/api/v2/components.json'
    requisicao=requests.get(url)
    reqJ = requisicao.json()['regionHealthReports'][2]['serviceHealthReports']
    
    for i in range(0, len(reqJ)):
        if(reqJ[i]['serviceStatus'] == "NormalPerformance"):
            normal_performace += 1
            print("\nServiço: " + reqJ[i]['serviceName'] + "\nStatus: " + reqJ[i]['serviceStatus'] + "\n")
        else:
            no_normal_performace += 1
            print("\nServiço: " + reqJ[i]['serviceName'] + "\nStatus: " + reqJ[i]['serviceStatus'] + "\n")

    print("Normal Performance: ", normal_performace)
    print("No Normal Performance: ", no_normal_performace)

def performaceOracleCloudVinhedo():
    global normal_performace 
    global no_normal_performace

    url = 'https://ocistatus.oraclecloud.com/api/v2/components.json'
    requisicao=requests.get(url)
    reqJ = requisicao.json()['regionHealthReports'][3]['serviceHealthReports']
    
    for i in range(0, len(reqJ)):
        if(reqJ[i]['serviceStatus'] == "NormalPerformance"):
            normal_performace += 1
            print("\nServiço: " + reqJ[i]['serviceName'] + "\nStatus: " + reqJ[i]['serviceStatus'] + "\n")
        else:
            no_normal_performace += 1
            print("\nServiço: " + reqJ[i]['serviceName'] + "\nStatus: " + reqJ[i]['serviceStatus'] + "\n")

    print("Normal Performance: ", normal_performace)
    print("No Normal Performance: ", no_normal_performace)


print("Performance São Paulo")
performaceOracleCloudSaoPaulo()
print("Performance Vinhedo")
performaceOracleCloudVinhedo()

schedule.every(1).minutes.do(performaceOracleCloudSaoPaulo, performaceOracleCloudVinhedo)

def enviarEmail(no_normal_performace):
    import win32com.client as win32

    #Interpretação com o outlook
    outlook = win32.Dispatch('outlook.application')
    
    #cria um e-mail
    email= outlook.CreateItem(0)

    #configurando do e-mail a ser enviado
    email.To = 'eduardo.toledo@germinare.org.br' #destino
    email.Subject= 'Email autommatico do python' #assunto
    email.HTMLBody= f''' 
    <p>Teste de email {no_normal_performace}</p>
    ''' #corpo

    # verifica se tem erro para enviar
    if no_normal_performace != 0:
        email.Send()
        print('Enviado')
    else:
        print('não enviado, esta tudo dando certo')

enviarEmail(no_normal_performace)

