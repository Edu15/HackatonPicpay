def enviar_email():
    import win32com.client as win32
    #Interpretação com o outlook
    outlook = win32.Dispatch('outlook.application')
                
    #cria um e-mail
    email= outlook.CreateItem(0)

    #configurando do e-mail a ser enviado
    email.To = 'eduardo.toledo@germinare.org.br' #destino
    email.Subject= 'Email autommatico do python' #assunto
    email.HTMLBody= f''' 
    <p><style="color: red">ERRO no alassian</p>
    ''' #corpo
    email.Send()
    print('Enviado')

import jinja2
def atassian():
    import requests
    import time
    import json
    import os
    while True:
    
        c = 0
        erro = {}
        infos = {}
    
        requisição = requests.get(
            "https://jira-software.status.atlassian.com/api/v2/summary.json")
    
        # <Response [200]>
    
        reqJ = requisição.json()
    
    
        for components in reqJ["components"]:
        
            if components['status'] == 'operational':
                #SE DER CERTO
                name = components["name"]
                status = components["status"]
                infos[name] = status

                enviar_email()

            else:
                #SE DER ERRADO
                name = components["name"]
                status = components["status"]
                erro[name] = status
            
        for i in infos:
            print(f'Esta Funcionado o: {i}')
    
        for i in erro:
            print(f'Esta dando erro no: {i}')
    
        objet_json = json.dumps(infos, indent=4)
        with open("jira/status.json", "w") as file:
            file.write(objet_json)
    
        for i in range(240):
            time.sleep(1)
            time.sleep(0.5)
            os.system('cls')
            print('Aguarde.')
            time.sleep(0.5)
            os.system('cls')
            print('Aguarde..')
            time.sleep(0.5)
            os.system('cls')
            print('Aguarde...')
atassian()